/* ==========================================================================
   MosaicRay — app.js
   Progressive enhancement only. The site is fully readable without JS.
   - In-memory theme toggle (no storage; resets to system preference on load)
   - Mobile navigation disclosure
   - Table-of-contents highlighting on long pages
   ========================================================================== */
(function () {
  'use strict';

  var root = document.documentElement;

  /* --- Theme ------------------------------------------------------------- */
  var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  var theme = prefersDark ? 'dark' : 'light'; // in-memory only, per session view

  function applyTheme(next) {
    theme = next;
    root.setAttribute('data-theme', theme);
    var btn = document.querySelector('.theme-toggle');
    if (btn) {
      btn.setAttribute('aria-pressed', String(theme === 'dark'));
      btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
    }
  }

  applyTheme(theme);

  document.addEventListener('click', function (e) {
    var toggle = e.target.closest && e.target.closest('.theme-toggle');
    if (!toggle) return;
    applyTheme(theme === 'dark' ? 'light' : 'dark');
  });

  /* --- Mobile navigation -------------------------------------------------- */
  var navToggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('primary-nav');

  function isMobile() { return window.matchMedia('(max-width: 860px)').matches; }

  function setNav(open) {
    if (!nav || !navToggle) return;
    if (isMobile()) {
      nav.hidden = !open;
      navToggle.setAttribute('aria-expanded', String(open));
    } else {
      nav.hidden = false;
      navToggle.setAttribute('aria-expanded', 'false');
    }
  }

  if (navToggle && nav) {
    setNav(false);
    navToggle.addEventListener('click', function () {
      setNav(nav.hidden);
    });
    nav.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' && isMobile()) setNav(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && isMobile() && !nav.hidden) {
        setNav(false);
        navToggle.focus();
      }
    });
    window.addEventListener('resize', function () { setNav(false); });
  }

  /* --- Table of contents highlighting -------------------------------------- */
  var tocLinks = Array.prototype.slice.call(document.querySelectorAll('.toc a'));
  if (tocLinks.length && 'IntersectionObserver' in window) {
    var map = {};
    tocLinks.forEach(function (link) {
      var id = link.getAttribute('href').replace('#', '');
      var section = document.getElementById(id);
      if (section) map[id] = link;
    });
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        var link = map[entry.target.id];
        if (!link) return;
        if (entry.isIntersecting) {
          tocLinks.forEach(function (l) { l.removeAttribute('aria-current'); l.style.borderLeftColor = ''; l.style.color = ''; });
          link.setAttribute('aria-current', 'true');
          link.style.borderLeftColor = 'var(--accent)';
          link.style.color = 'var(--ink)';
        }
      });
    }, { rootMargin: '-15% 0px -70% 0px' });
    Object.keys(map).forEach(function (id) { observer.observe(document.getElementById(id)); });
  }
})();
