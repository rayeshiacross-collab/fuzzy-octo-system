# MosaicRay — redesigned author site

Static HTML/CSS/JS. No build step, no dependencies, no tracking. Deploys as-is to
Netlify, Cloudflare Pages, or GitHub Pages (publish directory = repository root).

## Files
- `index.html` — homepage: hero, three paths (Readers / Writers / the wider thing),
  The Work, writer resources, orientation (Start Here + FAQ), The Seedbed, Also Growing.
- `start-here.html` — orientation copy, preserved from `start-here-page-copy.md`.
- `faq.html` — beginner questions, preserved from `faq-page-copy.md`, grouped into three sections.
- `base.css` — design tokens (colour, type, space), reset, a11y primitives, light/dark themes.
- `style.css` — components and page composition.
- `app.js` — in-memory theme toggle, mobile nav disclosure, TOC highlighting. Site works without JS.
- `favicon.svg`, `assets/og-image.png` — mosaic mark and social card.
- `qa/` — QA screenshots and script. Git-ignored; excluded from deploys.

## Conventions
- Colour, type and spacing come from CSS custom properties in `base.css`. Add new colours
  as tokens, not hex literals in `style.css`.
- The only decorative motif is the mosaic: rectangular fragments on a 3px gutter grid
  (`.mosaic`, `.frag-rule`, `.mosaic-strip`, `.series-chip`, `.growing-field`, the logo).
- Where a destination does not exist, use the non-clickable `.status` label. Never `href="#"`.
- External links: `target="_blank" rel="noopener noreferrer"` plus a visually hidden
  "(opens in a new tab)" note.
- All internal links are relative (`./page.html`).

## Content rules baked in
- No invented publication dates, cover art, buy links, credentials, testimonials,
  biography facts, or contact details.
- No claim of a human-review service anywhere, and no links to unavailable services.
- The Seedbed is presented as being planted, with no join link.
- "Also Growing" stays intentionally unnamed.
