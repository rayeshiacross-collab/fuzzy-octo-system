const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const pages = ['index','start-here','faq'];
  const results = [];
  for (const vp of [{n:'desktop',w:1440,h:1000},{n:'mobile',w:375,h:820}]) {
    const ctx = await b.newContext({viewport:{width:vp.w,height:vp.h}, deviceScaleFactor:1});
    const p = await ctx.newPage();
    for (const name of pages) {
      await p.goto('http://localhost:8791/'+name+'.html', {waitUntil:'networkidle'});
      const overflow = await p.evaluate(() => {
        const de = document.documentElement;
        const bad = [];
        document.querySelectorAll('body *').forEach(el => {
          const r = el.getBoundingClientRect();
          if (r.width > 0 && (r.right > window.innerWidth + 1)) bad.push(el.tagName + '.' + (el.className||'').toString().slice(0,40));
        });
        return {scrollW: de.scrollWidth, innerW: window.innerWidth, bad: bad.slice(0,8)};
      });
      results.push({vp:vp.n, page:name, ...overflow});
      await p.screenshot({path:`qa/${name}-${vp.n}.png`, fullPage:true});
    }
    // dark theme homepage
    if (vp.n==='desktop') {
      await p.goto('http://localhost:8791/index.html',{waitUntil:'networkidle'});
      await p.click('.theme-toggle');
      await p.waitForTimeout(300);
      const theme = await p.getAttribute('html','data-theme');
      results.push({vp:'desktop', page:'index (toggled)', theme});
      await p.screenshot({path:'qa/index-desktop-dark.png', fullPage:true});
    }
    if (vp.n==='mobile') {
      await p.goto('http://localhost:8791/index.html',{waitUntil:'networkidle'});
      const navHiddenBefore = await p.locator('#primary-nav').isHidden();
      await p.click('.nav-toggle');
      await p.waitForTimeout(200);
      const navVisible = await p.locator('#primary-nav').isVisible();
      results.push({vp:'mobile', page:'nav toggle', navHiddenBefore, navVisible});
      await p.screenshot({path:'qa/index-mobile-nav-open.png'});
    }
    await ctx.close();
  }
  console.log(JSON.stringify(results,null,1));
  await b.close();
})();
